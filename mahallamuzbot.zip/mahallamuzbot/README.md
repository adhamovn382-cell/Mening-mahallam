# Mahallam Uzbot

Fuqarolardan ism-familiya, telefon raqami, mahalla, uy raqami so'raydigan,
so'ng qaysi hodim bilan bog'lanmoqchi ekanligini tanlatib, o'sha hodim
bilan foydalanuvchi o'rtasida to'g'ridan-to'g'ri murojaat/javob almashinuvini
ta'minlaydigan Telegram bot.

## Bot qanday ishlaydi

1. Foydalanuvchi `/start` bosadi — bot ishga tushadi va birinchi navbatda
   so'raydi: **"Siz kimsiz?"** — tugmalar: "🧍 Men fuqaroman" va
   "👔 Men mahalla hodimiman".

### Agar "Men fuqaroman" tanlansa

2. Ism-familiyasini so'raydi.
3. Telefon raqamini so'raydi (faqat raqamlar qabul qilinadi — masalan
   `+998901234567`, tugma orqali yuborish ham mumkin).
4. **"Qaysi mahallada yashaysiz?"** deb so'raydi va 68 ta mahalla nomini
   tugma qilib chiqaradi (faqat ro'yxatdagi mahallalardan birini tanlash
   mumkin, qo'lda yozib bo'lmaydi).
5. Uy raqamini so'raydi (faqat raqam qabul qilinadi).
6. "Bot ishga tushdi. Qaysi hodim bilan bog'lanmoqchisiz?" deb so'raydi va
   hodimlar lavozimlari tugma qilib chiqadi (Hokim yordamchisi, Xotin-
   qizlar faoli, Yoshlar yetakchisi, Ijtimoiy xodim, Mahalla raisi,
   Profilaktika Inspektori).
7. Foydalanuvchi bir hodimni tanlagach, bot **o'sha hodim haqida
   ma'lumot** (ism-familiyasi, telefon raqami, u hal qila oladigan
   vazifalar) ko'rsatadi va **"Ushbu hodim bilan bog'lanasizmi?"** deb
   so'raydi (Ha / Yo'q, boshqa hodim tanlash tugmalari bilan).
8. "Ha" bosilsa, bot: *"Sizni '<lavozim>' bilan bog'ladik. Murojaatingizni
   yozib qoldiring, siz bilan tez orada bog'lanishadi."* deb yozadi.
9. Foydalanuvchi murojaatini yozadi — bu matn, uning **ismi, manzili
   (mahalla + uy raqami) va telefon raqami** bilan birga tanlangan
   hodimning **shaxsiy Telegram chatiga** yuboriladi.
10. Hodim shu xabarga Telegram'ning **Reply** (javob berish) funksiyasi
    orqali javob yozsa, bot bu javobni **avtomatik ravishda** tegishli
    foydalanuvchiga yuboradi.
11. Barcha ro'yxatdan o'tishlar `murojaatlar.csv` fayliga yoziladi
    (Excelda ochiladi), va agar `ADMIN_CHAT_ID` sozlangan bo'lsa, shu
    chatga ham nusxa yuboriladi.

### Agar "Men mahalla hodimiman" tanlansa

2. Bot ism-familiyani so'raydi.
3. Kiritilgan ism `bot.py` faylidagi `HODIMLAR` ro'yxatidagi ismlardan
   biriga mos kelsa-kelmasligini tekshiradi (katta-kichik harf farqi
   muhim emas):
   - **Mos kelmasa** → "❌ Bunday xodim yo'q." deb javob beradi va
     boshidagi "Siz kimsiz?" menyusiga qaytaradi.
   - **Mos kelsa** → o'sha lavozimning chat ID'sini **shu odamning
     haqiqiy Telegram chatiga avtomatik bog'lab qo'yadi**, "✅ Siz
     xodimsiz!" deb javob beradi, so'ng **telefon raqamini** va
     **"Qaysi mahallada ishlaysiz?"** deb 68 ta mahalladan birini
     tanlashni so'raydi. Oxirida: *"✅ Ma'lumotlaringiz saqlandi!
     Sizga kelib tushadigan barcha ma'lumotlar sizga yo'naltiriladi."*
     deb javob beradi, tugmalarni olib tashlaydi. Shundan keyin
     fuqarolardan o'sha lavozimga yo'llangan barcha murojaatlar shu
     odamning shaxsiy chatiga tushadi.

**Diqqat**: hozircha `HODIMLAR` ro'yxatida faqat bitta test ismi bor —
**"Adhamov Nurmuhammad"** ("Mahalla raisi" lavozimida). Haqiqiy
hodimlarning ism-familiyasini kiritish uchun pastdagi bo'limga qarang.

## Hodimlar ro'yxatini sozlash

`bot.py` faylining boshidagi `HODIMLAR` ro'yxatini haqiqiy ma'lumotlar
bilan to'ldiring:

```python
HODIMLAR = [
    {
        "lavozim": "Hokim yordamchisi",
        "ism": "Falonchiyev Falonchi",   # Hodim /start bosib shu ismni kiritadi
        "telefon": "+998 90 123 45 67",  # Fuqaroga ko'rsatiladigan raqam
        "vazifa": "Hokimlik bilan bog'liq umumiy masalalar",
        "chat_id": "111111111",           # Hodim o'zi ro'yxatdan o'tgach avtomatik yangilanadi
    },
    # ... qolgan hodimlar shu tartibda
]
```

- `lavozim` — foydalanuvchiga tugma sifatida ko'rinadi.
- `ism` — hodim "👔 Men mahalla hodimiman" tugmasini bosib, o'zini
  tasdiqlash uchun aynan shu ismni kiritishi kerak (katta-kichik harf
  farqi muhim emas).
- `telefon`, `vazifa` — fuqaroga ma'lumot sifatida ko'rsatiladi.
- `chat_id` — murojaatlar shu Telegram chat ID'siga yuboriladi. Buni
  qo'lda oldindan to'ldirishingiz shart emas — hodim o'zi "Men mahalla
  hodimiman" orqali ro'yxatdan o'tganda **avtomatik yangilanadi**.
  Xohlasangiz, oldindan ham qo'lda kiritib qo'yishingiz mumkin (masalan
  [@userinfobot](https://t.me/userinfobot) orqali ID olib).

Yangi hodim qo'shish uchun ro'yxatga yangi obyekt qo'shing; olib
tashlash uchun kerakli obyektni o'chiring.

**MUHIM shart**: Telegram bot birinchi bo'lib notanish foydalanuvchiga
yozishga ruxsat bermaydi. Shuning uchun **har bir hodim botga kamida
bir marta `/start` bosib, "Men mahalla hodimiman" orqali o'zini
tasdiqlashi shart** — aks holda ularga murojaat yuborilganda xatolik
chiqadi (bu xatolik faqat log'da ko'rinadi, foydalanuvchiga
bildirilmaydi).

**Eslatma**: Hodimning runtime'da o'zgargan `chat_id`si va murojaat
xabari-foydalanuvchi bog'lanishi xotirada (RAM'da) saqlanadi — bot
qayta ishga tushirilsa, hodim `bot.py` faylida qo'lda kiritilgan
`chat_id`siga qaytadi (agar bo'lmasa, qayta "Men mahalla hodimiman"
orqali ro'yxatdan o'tishi kerak) va eski murojaatlarga javob berish
imkoniyati yo'qoladi (yangi murojaatlar muammosiz ishlayveradi).


## O'rnatish

1. Python 3.10+ o'rnatilgan bo'lishi kerak.
2. Kerakli kutubxonalarni o'rnating:

   ```bash
   pip install -r requirements.txt
   ```

3. Telegram'da [@BotFather](https://t.me/BotFather) orqali yangi bot
   yarating va tokenni oling (masalan `123456789:AAExampleToken`).

4. Tokenni muhit o'zgaruvchisi sifatida bering:

   **Linux / macOS:**
   ```bash
   export BOT_TOKEN="SIZNING_TOKENINGIZ"
   ```

   **Windows (PowerShell):**
   ```powershell
   $env:BOT_TOKEN="SIZNING_TOKENINGIZ"
   ```

   Yoki `bot.py` faylida to'g'ridan-to'g'ri `BOT_TOKEN = "..."` qatoriga
   yozib qo'yishingiz ham mumkin.

5. (Ixtiyoriy) Barcha ro'yxatdan o'tishlar nusxasini olib turadigan
   guruh yoki shaxsiy chat ID'sini bering:

   ```bash
   export ADMIN_CHAT_ID="123456789"
   ```

## Ishga tushirish

```bash
python bot.py
```

Bot ishga tushgach, Telegram'da botingizga o'ting va `/start` bosing.

## Ma'lumotlar qayerda saqlanadi

Har bir ro'yxatdan o'tish `murojaatlar.csv` fayliga qo'shiladi (sana,
foydalanuvchi, ism-familiya, telefon, mahalla, uy raqami, tanlangan
hodim). Faylni Excel yoki Google Sheets'da ochishingiz mumkin.

## Mahallalar ro'yxatini o'zgartirish

`bot.py` faylining boshida `MAHALLALAR` ro'yxatini tahrirlab, xohlagan
mahalla nomlarini qo'shishingiz yoki o'chirishingiz mumkin. Hozircha 68 ta
mahalla ro'yxatda (fuqaro ham, hodim ham shu ro'yxatdan tanlaydi).

## Botni doimiy ishlab turishi uchun (server)

Kompyuteringiz o'chsa bot ham to'xtaydi. Botni doimiy ishlatish uchun uni
arzon VPS serverga (masalan, Timeweb, Hetzner) joylashtirib,
`systemd` yoki `screen`/`tmux` yordamida orqa fonda ishga tushiring, yoki
`pm2`, `supervisord` kabi vositalardan foydalaning.

## Botni uxlab qolishdan saqlash (Render, Replit va h.k.)

Bepul hostinglar bot ma'lum vaqt faolsiz tursa uni uxlatib qo'yadi.
Buning oldini olish uchun bot ichida `keepalive.py` bor:

- kichik veb-server ochadi (`PORT` muhit o'zgaruvchisi bo'yicha);
- `PUBLIC_URL` (Render'da `RENDER_EXTERNAL_URL` avtomatik) berilgan bo'lsa,
  **har 60 soniyada** o'z manziliga so'rov yuborib turadi.

Hostingda quyidagi muhit o'zgaruvchilarini kiriting:

```
BOT_TOKEN = <BotFather tokeni>
PUBLIC_URL = https://sizning-botingiz.onrender.com
```

Qo'shimcha kafolat uchun [cron-job.org](https://cron-job.org) da bepul
vazifa yarating: shu `PUBLIC_URL` ga har 1 daqiqada GET so'rov. Bot
allaqachon uxlab qolgan bo'lsa, uni tashqi xizmat uyg'otadi.

**Tokenni GitHub'ga yuklamang** — u faqat hostingning "Environment
Variables" bo'limida turishi kerak (`.gitignore` tayyor).
