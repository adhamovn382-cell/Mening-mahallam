# -*- coding: utf-8 -*-
"""
Botni bepul hostinglarda (Render, Replit va h.k.) uxlab qolishdan saqlash.

1) Kichik veb-server ochadi — hosting "bu xizmat tirik" deb hisoblaydi va
   tashqaridan (masalan cron-job.org / UptimeRobot) ping qilish mumkin.
2) Har 60 soniyada botning o'z ochiq manziliga so'rov yuboradi — shunda
   hosting uni "faolsiz" deb uxlatib qo'ymaydi.

Faqat standart kutubxonalar ishlatiladi, qo'shimcha o'rnatish shart emas.
"""

import logging
import os
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

logger = logging.getLogger(__name__)

PING_INTERVAL = 60  # soniya


class _Handler(BaseHTTPRequestHandler):
    def _javob(self, body=True):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        if body:
            self.wfile.write("Mahallam Uzbot ishlayapti".encode("utf-8"))

    def do_GET(self):
        self._javob(True)

    def do_HEAD(self):
        self._javob(False)

    def log_message(self, *args):
        pass  # ortiqcha log chiqarmaslik uchun


def _public_url():
    """Botning ochiq manzilini muhit o'zgaruvchilaridan aniqlaydi."""
    url = os.environ.get("PUBLIC_URL") or os.environ.get("RENDER_EXTERNAL_URL")
    if not url and os.environ.get("REPLIT_DEV_DOMAIN"):
        url = "https://" + os.environ["REPLIT_DEV_DOMAIN"]
    return url


def start_server():
    port = int(os.environ.get("PORT", "8080"))
    try:
        server = HTTPServer(("0.0.0.0", port), _Handler)
    except OSError as e:
        logger.warning("Keep-alive server ochilmadi (port %s band): %s", port, e)
        return False
    threading.Thread(target=server.serve_forever, daemon=True).start()
    logger.info("Keep-alive server %s portda ishga tushdi", port)
    return True


def start_self_ping():
    url = _public_url()
    if not url:
        logger.info(
            "PUBLIC_URL sozlanmagan — o'z-o'zini ping qilish o'chirilgan "
            "(tashqi ping xizmati ishlatilsa ham bo'ladi)."
        )
        return False

    def loop():
        while True:
            time.sleep(PING_INTERVAL)
            try:
                urllib.request.urlopen(url, timeout=15).read()
            except Exception as e:
                logger.warning("Self-ping xatosi: %s", e)

    threading.Thread(target=loop, daemon=True).start()
    logger.info("Self-ping har %s soniyada: %s", PING_INTERVAL, url)
    return True


def start():
    start_server()
    start_self_ping()
