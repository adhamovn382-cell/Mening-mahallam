# -*- coding: utf-8 -*-
"""
Mahallam Uzbot — Telegram bot
Fuqarolardan: Ism-familiya, telefon raqami, mahalla nomi, uy raqami va
qaysi hodim bilan bog'lanmoqchi ekanligini so'rab, tanlangan hodim
haqida ma'lumot ko'rsatadi, tasdiqdan so'ng murojaat matnini oladi va
uni hodimning shaxsiy Telegram chatiga yuboradi. Hodim shu xabarga
Telegram "Reply" funksiyasi orqali javob yozsa, javob avtomatik
foydalanuvchiga qaytariladi.
"""

import asyncio
import csv
import logging
import os
import re
from datetime import datetime

import keepalive
from telegram import (
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    Update,
)
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

# ---------------------------------------------------------------------------
# SOZLAMALAR
# ---------------------------------------------------------------------------

# BotFather'dan olingan tokenni shu yerga yozing yoki muhit o'zgaruvchisi
# (environment variable) sifatida bering: export BOT_TOKEN="123:ABC..."
BOT_TOKEN = os.environ.get("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

# Barcha murojaatlar (kimga yuborilishidan qat'i nazar) shu chat/guruhga
# ham nusxa sifatida yuborilsin desangiz, shu yerga chat ID yozing.
# Bo'sh qoldirsangiz, faqat CSV faylga yoziladi.
ADMIN_CHAT_ID = os.environ.get("ADMIN_CHAT_ID", "")

DATA_FILE = os.path.join(os.path.dirname(__file__), "murojaatlar.csv")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# MAHALLALAR RO'YXATI
# ---------------------------------------------------------------------------

MAHALLALAR = [
    "Avg‘onbog‘",
    "Aziztepa",
    "Alisher Navoiy",
    "Artizon bo‘yi",
    "At-Termiziy",
    "Achchiqko‘l",
    "Ashirqulmergan",
    "Ashurali Zoxiriy",
    "Baqachorsu",
    "Bo‘ston",
    "Vaqf chorsu",
    "G‘alabaqqollik",
    "G‘alchasoy",
    "G‘ishtko‘prik",
    "G‘ishtli masjid",
    "G‘ozi yog‘lik",
    "Davronbek",
    "Degrezlik",
    "Do‘stlik",
    "Yog‘ bozori",
    "Zilol",
    "Islomobod",
    "Istiqbol",
    "Isfara guzari",
    "Kalvak guzari",
    "Katta Ganjiravon",
    "Qaymoqli guzar",
    "Qalandarhona",
    "Quduqlik",
    "Qo‘shchinor",
    "Marg‘ilon darvozasi",
    "Mingtut",
    "Misgarlik",
    "Mo‘yi muborak",
    "Muqimiy",
    "Mustaqillik",
    "Navro‘z",
    "Noib ko‘prigi",
    "Nonvoylik guzar",
    "Nurafshon",
    "Oydin buloq",
    "Oqoltin",
    "Oltin vodiy",
    "Parpashabof",
    "Rayxon",
    "Sadoqat",
    "Saodat",
    "Sobir Abdulla",
    "Sunbula",
    "Tolzor",
    "Toshkentli guzar",
    "To‘g‘onboshi",
    "To‘laboy",
    "Turkiston",
    "To‘xlimergan",
    "Uzumzor",
    "Urganjibog‘",
    "O‘rmonbog‘",
    "Charxini ko‘prigi",
    "Chodaklik",
    "Chorchinor",
    "Shayxon",
    "Shaldiramoq",
    "Shikorbegi",
    "Shirin",
    "Yalong‘och ota",
    "Yangi chorsu",
    "Yangiobod",
]

# ---------------------------------------------------------------------------
# MAHALLA HODIMLARI (MAS'UL SHAXSLAR) RO'YXATI
# ---------------------------------------------------------------------------
# Har bir hodim uchun: lavozimi, ism-familiyasi, telefon raqami, u hal
# qila oladigan vazifalar va shaxsiy Telegram chat ID'si.
#
# MUHIM: har bir hodim botga kamida bitta marta /start bosishi shart —
# aks holda Telegram botga notanish foydalanuvchiga birinchi bo'lib
# yozishga ruxsat bermaydi.

HODIMLAR = [
    {
        "lavozim": "Hokim yordamchisi",
        "ism": "Falonchiyev Falonchi",
        "telefon": "+998 90 123 45 67",
        "vazifa": "Hokimlik bilan bog'liq umumiy masalalar",
        "chat_id": "8303307264",
    },
    {
        "lavozim": "Xotin-qizlar faoli",
        "ism": "Pistonchiyeva Pistonoy",
        "telefon": "+998 91 234 56 78",
        "vazifa": "Ayollar va oila masalalari",
        "chat_id": "8303307264",
    },
    {
        "lavozim": "Yoshlar yetakchisi",
        "ism": "Bekchiyev Bekzod",
        "telefon": "+998 93 345 67 89",
        "vazifa": "Yoshlar bilan ishlash, sport va bo'sh vaqt",
        "chat_id": "8303307264",
    },
    {
        "lavozim": "Ijtimoiy xodim",
        "ism": "Karimova Karima",
        "telefon": "+998 94 456 78 90",
        "vazifa": "Ijtimoiy yordam va nafaqalar",
        "chat_id": "8303307264",
    },
    {
        "lavozim": "Mahalla raisi",
        "ism": "Adhamov Nurmuhammad",
        "telefon": "+998 95 567 89 01",
        "vazifa": "Mahalladagi umumiy masalalar",
        "chat_id": "8303307264",
    },
    {
        "lavozim": "Profilaktika Inspektori",
        "ism": "Yusupov Yusuf",
        "telefon": "+998 97 678 90 12",
        "vazifa": "Huquqbuzarliklarning oldini olish",
        "chat_id": "8303307264",
    },
]

HODIM_LAVOZIMLARI = [h["lavozim"] for h in HODIMLAR]

BOGLANISH_TUGMASI = "\u2705 Ha, bog'lanish"
ORQAGA_TUGMASI = "\u274C Yo'q, boshqa hodim tanlash"

FUQARO_TUGMASI = "\U0001F9CD Men fuqaroman"
HODIM_ROL_TUGMASI = "\U0001F454 Men mahalla hodimiman"

# ---------------------------------------------------------------------------
# SUHBAT HOLATLARI (STATES)
# ---------------------------------------------------------------------------

(
    ROL_TANLASH,
    HODIM_ISM_SORASH,
    HODIM_TELEFON,
    HODIM_MAHALLA,
    ISM_FAMILIYA,
    TELEFON,
    MAHALLA_TANLASH,
    UY_RAQAMI,
    HODIM_TANLASH,
    HODIM_TASDIQ,
    MUROJAAT_MATNI,
) = range(11)

# Telefon: +998901234567 yoki 998901234567 yoki 901234567 ko'rinishida,
# faqat raqamlardan iborat (bo'sh joy/chiziqchalarni tozalab tekshiramiz).
TELEFON_REGEX = re.compile(r"^\+?\d{9,13}$")

# Uy raqami: faqat raqamlar (kerak bo'lsa "12A" kabi bitta harf ham
# qo'shilishi mumkin bo'lsin desangiz pastdagi regexni o'zgartiring).
UY_RAQAMI_REGEX = re.compile(r"^\d{1,5}$")


def build_keyboard(items, columns=2):
    """Ro'yxatdan reply-klaviatura tugmalarini yaratadi."""
    rows = [items[i : i + columns] for i in range(0, len(items), columns)]
    return ReplyKeyboardMarkup(rows, resize_keyboard=True, one_time_keyboard=True)


def hodim_topish(lavozim):
    for h in HODIMLAR:
        if h["lavozim"] == lavozim:
            return h
    return None


def save_to_csv(row: dict):
    file_exists = os.path.isfile(DATA_FILE)
    with open(DATA_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "sana",
                "user_id",
                "username",
                "ism_familiya",
                "telefon",
                "mahalla",
                "uy_raqami",
                "hodim_lavozimi",
            ],
        )
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


# ---------------------------------------------------------------------------
# HANDLERLAR
# ---------------------------------------------------------------------------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    keyboard = ReplyKeyboardMarkup(
        [[FUQARO_TUGMASI], [HODIM_ROL_TUGMASI]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    await update.message.reply_text(
        "Assalomu alaykum! \U0001F44B\n"
        "\"Mahallam Uzbot\"ga xush kelibsiz.\n\n"
        "Siz kimsiz?",
        reply_markup=keyboard,
    )
    return ROL_TANLASH


async def rol_tanlash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    matn = update.message.text.strip()

    if matn == FUQARO_TUGMASI:
        await update.message.reply_text(
            "Iltimos, ism va familiyangizni to'liq kiriting:",
            reply_markup=ReplyKeyboardRemove(),
        )
        return ISM_FAMILIYA

    if matn == HODIM_ROL_TUGMASI:
        await update.message.reply_text(
            "Ism va familiyangizni to'liq kiriting:",
            reply_markup=ReplyKeyboardRemove(),
        )
        return HODIM_ISM_SORASH

    keyboard = ReplyKeyboardMarkup(
        [[FUQARO_TUGMASI], [HODIM_ROL_TUGMASI]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    await update.message.reply_text(
        "Iltimos, pastdagi tugmalardan birini tanlang.",
        reply_markup=keyboard,
    )
    return ROL_TANLASH


async def hodim_ism_sorash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    kiritilgan_ism = update.message.text.strip()

    topilgan_hodim = None
    for h in HODIMLAR:
        if h["ism"].strip().lower() == kiritilgan_ism.lower():
            topilgan_hodim = h
            break

    if not topilgan_hodim:
        keyboard = ReplyKeyboardMarkup(
            [[FUQARO_TUGMASI], [HODIM_ROL_TUGMASI]],
            resize_keyboard=True,
            one_time_keyboard=True,
        )
        await update.message.reply_text(
            "\u274C Bunday xodim yo'q.",
            reply_markup=keyboard,
        )
        return ROL_TANLASH

    # Shu hodimning chat ID'sini shu foydalanuvchining haqiqiy Telegram
    # chatiga bog'lab qo'yamiz — bundan buyon shu lavozimga yo'llangan
    # barcha murojaatlar shu chatga tushadi.
    topilgan_hodim["chat_id"] = str(update.effective_chat.id)
    context.user_data["hodim_nomzod"] = topilgan_hodim

    telefon_tugma = KeyboardButton(
        "\U0001F4DE Telefon raqamimni yuborish", request_contact=True
    )
    keyboard = ReplyKeyboardMarkup(
        [[telefon_tugma]], resize_keyboard=True, one_time_keyboard=True
    )
    await update.message.reply_text(
        f"\u2705 Siz xodimsiz! ({topilgan_hodim['lavozim']})\n\n"
        "Endi telefon raqamingizni yuboring "
        "(tugmani bosing yoki qo'lda +998xxxxxxxxx ko'rinishida yozing):",
        reply_markup=keyboard,
    )
    return HODIM_TELEFON


async def hodim_telefon(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.contact:
        raqam = update.message.contact.phone_number
    else:
        raqam = update.message.text.strip()

    tozalangan = re.sub(r"[\s\-()]", "", raqam)

    if not TELEFON_REGEX.match(tozalangan):
        telefon_tugma = KeyboardButton(
            "\U0001F4DE Telefon raqamimni yuborish", request_contact=True
        )
        keyboard = ReplyKeyboardMarkup(
            [[telefon_tugma]], resize_keyboard=True, one_time_keyboard=True
        )
        await update.message.reply_text(
            "\u274C Telefon raqami noto'g'ri kiritildi.\n"
            "Iltimos, faqat raqamlardan iborat holda kiriting "
            "(masalan: +998901234567) yoki pastdagi tugmani bosing:",
            reply_markup=keyboard,
        )
        return HODIM_TELEFON

    context.user_data["hodim_telefon"] = tozalangan

    await update.message.reply_text(
        "Qaysi mahallada ishlaysiz? Quyidagi ro'yxatdan tanlang:",
        reply_markup=build_keyboard(MAHALLALAR, columns=2),
    )
    return HODIM_MAHALLA


async def hodim_mahalla(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    tanlangan = update.message.text.strip()
    if tanlangan not in MAHALLALAR:
        await update.message.reply_text(
            "Iltimos, ro'yxatdagi tugmalardan birini tanlang.",
            reply_markup=build_keyboard(MAHALLALAR, columns=2),
        )
        return HODIM_MAHALLA

    hodim = context.user_data.get("hodim_nomzod")
    if hodim is not None:
        hodim["shaxsiy_telefon"] = context.user_data.get("hodim_telefon")
        hodim["ish_mahallasi"] = tanlangan

    await update.message.reply_text(
        f"\u2705 Ma'lumotlaringiz saqlandi!\n\n"
        f"\U0001F3E2 Mahalla: {tanlangan}\n\n"
        "Sizga kelib tushadigan barcha ma'lumotlar sizga yo'naltiriladi.",
        reply_markup=ReplyKeyboardRemove(),
    )
    context.user_data.clear()
    return ConversationHandler.END


async def ism_familiya(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["ism_familiya"] = update.message.text.strip()

    telefon_tugma = KeyboardButton(
        "\U0001F4DE Telefon raqamimni yuborish", request_contact=True
    )
    keyboard = ReplyKeyboardMarkup(
        [[telefon_tugma]], resize_keyboard=True, one_time_keyboard=True
    )
    await update.message.reply_text(
        "Rahmat! Endi telefon raqamingizni yuboring "
        "(tugmani bosing yoki qo'lda +998xxxxxxxxx ko'rinishida yozing):",
        reply_markup=keyboard,
    )
    return TELEFON


async def telefon(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.contact:
        raqam = update.message.contact.phone_number
    else:
        raqam = update.message.text.strip()

    # Tekshirish uchun bo'shliq, tire va qavslarni olib tashlaymiz
    tozalangan = re.sub(r"[\s\-()]", "", raqam)

    if not TELEFON_REGEX.match(tozalangan):
        telefon_tugma = KeyboardButton(
            "\U0001F4DE Telefon raqamimni yuborish", request_contact=True
        )
        keyboard = ReplyKeyboardMarkup(
            [[telefon_tugma]], resize_keyboard=True, one_time_keyboard=True
        )
        await update.message.reply_text(
            "\u274C Telefon raqami noto'g'ri kiritildi.\n"
            "Iltimos, faqat raqamlardan iborat holda kiriting "
            "(masalan: +998901234567) yoki pastdagi tugmani bosing:",
            reply_markup=keyboard,
        )
        return TELEFON

    context.user_data["telefon"] = tozalangan

    await update.message.reply_text(
        "Qaysi mahallada yashaysiz? Quyidagi ro'yxatdan tanlang:",
        reply_markup=build_keyboard(MAHALLALAR, columns=2),
    )
    return MAHALLA_TANLASH


async def mahalla_tanlash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    tanlangan = update.message.text.strip()
    if tanlangan not in MAHALLALAR:
        await update.message.reply_text(
            "Iltimos, ro'yxatdagi tugmalardan birini tanlang.",
            reply_markup=build_keyboard(MAHALLALAR, columns=2),
        )
        return MAHALLA_TANLASH

    context.user_data["mahalla"] = tanlangan
    await update.message.reply_text(
        f"\"{tanlangan}\" mahallasi uy raqamini kiriting:",
        reply_markup=ReplyKeyboardRemove(),
    )
    return UY_RAQAMI


async def uy_raqami(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    matn = update.message.text.strip()

    if not UY_RAQAMI_REGEX.match(matn):
        await update.message.reply_text(
            "\u274C Uy raqami noto'g'ri kiritildi.\n"
            "Iltimos, faqat raqam kiriting (masalan: 12):"
        )
        return UY_RAQAMI

    context.user_data["uy_raqami"] = matn

    await update.message.reply_text(
        "Bot ishga tushdi \u2705\nQaysi hodim bilan bog'lanmoqchisiz?",
        reply_markup=build_keyboard(HODIM_LAVOZIMLARI, columns=1),
    )
    return HODIM_TANLASH


async def hodim_tanlash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    tanlangan = update.message.text.strip()
    hodim = hodim_topish(tanlangan)

    if not hodim:
        await update.message.reply_text(
            "Iltimos, ro'yxatdagi tugmalardan birini tanlang.",
            reply_markup=build_keyboard(HODIM_LAVOZIMLARI, columns=1),
        )
        return HODIM_TANLASH

    context.user_data["hodim"] = hodim

    malumot = (
        f"\U0001F464 Lavozimi: {hodim['lavozim']}\n"
        f"\U0001F4DD Ism familiya: {hodim['ism']}\n"
        f"\U0001F4DE Telefon: {hodim['telefon']}\n"
        f"\U0001F4CB Vazifasi: {hodim['vazifa']}\n\n"
        f"Ushbu hodim bilan bog'lanasizmi?"
    )
    keyboard = ReplyKeyboardMarkup(
        [[BOGLANISH_TUGMASI], [ORQAGA_TUGMASI]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    await update.message.reply_text(malumot, reply_markup=keyboard)
    return HODIM_TASDIQ


async def hodim_tasdiq(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    matn = update.message.text.strip()

    if matn == ORQAGA_TUGMASI:
        await update.message.reply_text(
            "Qaysi hodim bilan bog'lanmoqchisiz?",
            reply_markup=build_keyboard(HODIM_LAVOZIMLARI, columns=1),
        )
        return HODIM_TANLASH

    if matn != BOGLANISH_TUGMASI:
        keyboard = ReplyKeyboardMarkup(
            [[BOGLANISH_TUGMASI], [ORQAGA_TUGMASI]],
            resize_keyboard=True,
            one_time_keyboard=True,
        )
        await update.message.reply_text(
            "Iltimos, pastdagi tugmalardan birini tanlang.",
            reply_markup=keyboard,
        )
        return HODIM_TASDIQ

    hodim = context.user_data.get("hodim")

    # Ro'yxatdan o'tish ma'lumotlarini shu bosqichda saqlab qo'yamiz
    user = update.effective_user
    data = context.user_data
    row = {
        "sana": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "user_id": user.id,
        "username": f"@{user.username}" if user.username else "",
        "ism_familiya": data.get("ism_familiya"),
        "telefon": data.get("telefon"),
        "mahalla": data.get("mahalla"),
        "uy_raqami": data.get("uy_raqami"),
        "hodim_lavozimi": hodim["lavozim"] if hodim else "",
    }
    save_to_csv(row)

    # Profilni keyinroq foydalanish uchun saqlab qo'yamiz
    context.bot_data.setdefault("profillar", {})[user.id] = {
        "ism_familiya": data.get("ism_familiya"),
        "telefon": data.get("telefon"),
        "mahalla": data.get("mahalla"),
        "uy_raqami": data.get("uy_raqami"),
    }

    if ADMIN_CHAT_ID:
        try:
            admin_xabar = (
                "\U0001F4E5 Yangi ro'yxatdan o'tish!\n\n"
                f"\U0001F464 {row['ism_familiya']}\n"
                f"\U0001F4DE {row['telefon']}\n"
                f"\U0001F3E0 {row['mahalla']}, {row['uy_raqami']}-uy\n"
                f"\U0001F4E9 Tanlangan hodim: {row['hodim_lavozimi']}\n"
                f"\U0001F517 {row['username']}"
            )
            await context.bot.send_message(chat_id=ADMIN_CHAT_ID, text=admin_xabar)
        except Exception as e:
            logger.error("Adminga xabar yuborishda xatolik: %s", e)

    await update.message.reply_text(
        f"Sizni \"{hodim['lavozim']}\" bilan bog'ladik.\n"
        "Murojaatingizni yozib qoldiring, siz bilan tez orada bog'lanishadi.",
        reply_markup=ReplyKeyboardRemove(),
    )
    return MUROJAAT_MATNI


async def murojaat_matni(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    matn = update.message.text
    hodim = context.user_data.get("hodim")

    if not hodim or not hodim.get("chat_id"):
        await update.message.reply_text(
            "\u26A0\uFE0F Hozircha bu hodim ulanmagan. "
            "Iltimos, administrator bilan bog'laning."
        )
        context.user_data.clear()
        return ConversationHandler.END

    profil = context.bot_data.get("profillar", {}).get(user.id, {})
    ism = profil.get("ism_familiya") or user.full_name
    manzil = (
        f"{profil.get('mahalla', '?')} mahallasi, "
        f"{profil.get('uy_raqami', '?')}-uy"
    )
    telefon_raqami = profil.get("telefon") or "-"

    xabar = (
        f"\U0001F4E5 Sizga yangi murojaat keldi! ({hodim['lavozim']})\n\n"
        f"\U0001F464 Ism familiya: {ism}\n"
        f"\U0001F3E0 Manzil: {manzil}\n"
        f"\U0001F4DE Telefon: {telefon_raqami}\n"
        f"\U0001F517 Username: {'@' + user.username if user.username else '-'}\n\n"
        f"\U0001F4AC Murojaat matni:\n{matn}\n\n"
        "\u2139\uFE0F Javob berish uchun shu xabarga \"Reply\" qiling."
    )

    try:
        yuborilgan = await context.bot.send_message(
            chat_id=hodim["chat_id"], text=xabar
        )
        # Hodim shu xabarga "Reply" qilganda javobni to'g'ri foydalanuvchiga
        # qaytarish uchun (hodim_chat_id, xabar_id) juftligini foydalanuvchi
        # chat ID'siga bog'lab qo'yamiz.
        kalit = (yuborilgan.chat_id, yuborilgan.message_id)
        context.bot_data.setdefault("murojaat_xabarlari", {})[
            kalit
        ] = update.effective_chat.id
    except Exception as e:
        logger.error(
            "Hodimga (%s) xabar yuborishda xatolik: %s", hodim["lavozim"], e
        )

    await update.message.reply_text(
        "\u2705 Murojaatingiz yuborildi. Tez orada siz bilan bog'lanishadi."
    )
    context.user_data.clear()
    return ConversationHandler.END


async def hodim_javobi(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Hodim o'ziga yuborilgan murojaatga "Reply" qilganda, javobni
    tegishli foydalanuvchiga yuboradi. Hodim ID'lari runtime'da o'zgarishi
    mumkinligi sababli, tekshiruv (chat_id, xabar_id) juftligi orqali
    amalga oshiriladi — shuning uchun bu handler har qanday chatdan
    kelgan "Reply" xabarlarni tekshiradi, lekin mos yozuv topilmasa
    hech narsa qilmaydi."""
    reply_to = update.message.reply_to_message
    if not reply_to:
        return

    mapping = context.bot_data.get("murojaat_xabarlari", {})
    kalit = (update.effective_chat.id, reply_to.message_id)
    user_chat_id = mapping.get(kalit)
    if not user_chat_id:
        return

    try:
        await context.bot.send_message(
            chat_id=user_chat_id,
            text=f"\U0001F4E9 Mahalla hodimi javobi:\n\n{update.message.text}",
        )
        await update.message.reply_text("\u2705 Javobingiz foydalanuvchiga yuborildi.")
    except Exception as e:
        logger.error("Foydalanuvchiga javob yuborishda xatolik: %s", e)
        await update.message.reply_text(
            "\u274C Javobni yuborib bo'lmadi. Foydalanuvchi botni bloklagan bo'lishi mumkin."
        )


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    await update.message.reply_text(
        "Bekor qilindi. Qaytadan boshlash uchun /start buyrug'ini yuboring.",
        reply_markup=ReplyKeyboardRemove(),
    )
    return ConversationHandler.END


async def unknown(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "Boshlash uchun /start buyrug'ini yuboring."
    )


# ---------------------------------------------------------------------------
# ASOSIY FUNKSIYA
# ---------------------------------------------------------------------------

def main() -> None:
    if not BOT_TOKEN or BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        raise SystemExit(
            "Xatolik: BOT_TOKEN sozlanmagan. README.md faylini o'qing."
        )

    # Python 3.12+ (ayniqsa 3.14) asosiy oqim (main thread) uchun ham
    # event loop'ni avtomatik yaratmay qo'ydi. python-telegram-bot buni
    # kutmaydi, shuning uchun uni o'zimiz oldindan yaratib qo'yamiz.
    try:
        asyncio.get_event_loop()
    except RuntimeError:
        asyncio.set_event_loop(asyncio.new_event_loop())

    # Hostingda uxlab qolmasligi uchun veb-server va har daqiqadagi self-ping
    keepalive.start()

    application = Application.builder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            ROL_TANLASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, rol_tanlash)],
            HODIM_ISM_SORASH: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, hodim_ism_sorash)
            ],
            HODIM_TELEFON: [
                MessageHandler(filters.CONTACT, hodim_telefon),
                MessageHandler(filters.TEXT & ~filters.COMMAND, hodim_telefon),
            ],
            HODIM_MAHALLA: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, hodim_mahalla)
            ],
            ISM_FAMILIYA: [MessageHandler(filters.TEXT & ~filters.COMMAND, ism_familiya)],
            TELEFON: [
                MessageHandler(filters.CONTACT, telefon),
                MessageHandler(filters.TEXT & ~filters.COMMAND, telefon),
            ],
            MAHALLA_TANLASH: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, mahalla_tanlash)
            ],
            UY_RAQAMI: [MessageHandler(filters.TEXT & ~filters.COMMAND, uy_raqami)],
            HODIM_TANLASH: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, hodim_tanlash)
            ],
            HODIM_TASDIQ: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, hodim_tasdiq)
            ],
            MUROJAAT_MATNI: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, murojaat_matni)
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    application.add_handler(conv_handler)

    # Hodim (o'zi ro'yxatdan o'tgan yoki oldindan sozlangan) o'ziga
    # yuborilgan murojaatga "Reply" qilsa, javob avtomatik tegishli
    # foydalanuvchiga yuboriladi. Hodimlarning chat ID'lari runtime'da
    # o'zgarishi mumkinligi sababli (self-registratsiya orqali), bu
    # handler oldindan belgilangan chat ro'yxatiga bog'lanmaydi — har
    # qanday "Reply" xabarni tekshiradi va faqat haqiqiy murojaatga mos
    # kelsagina javob yuboradi.
    application.add_handler(MessageHandler(filters.REPLY, hodim_javobi))

    application.add_handler(MessageHandler(filters.ALL, unknown))

    logger.info("Bot ishga tushmoqda...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
